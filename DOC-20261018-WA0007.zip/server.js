require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const path = require("path");
const bcrypt = require("bcryptjs");

const app = express();
const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/shopnova";

mongoose.connect(MONGODB_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error("MongoDB connection error:", err.message));

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ["user", "admin"], default: "user" }
}, { timestamps: true });

const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  description: { type: String, default: "" },
  category: { type: String, default: "General" },
  price: { type: Number, required: true, min: 0 },
  image: { type: String, default: "" },
  stock: { type: Number, default: 10, min: 0 },
  featured: { type: Boolean, default: false }
}, { timestamps: true });

const orderSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  items: [{
    product: { type: mongoose.Schema.Types.ObjectId, ref: "Product" },
    name: String,
    image: String,
    price: Number,
    quantity: { type: Number, min: 1 }
  }],
  total: { type: Number, required: true },
  shipping: {
    fullName: String, address: String, city: String, postalCode: String, phone: String
  },
  status: { type: String, enum: ["Placed", "Processing", "Shipped", "Delivered", "Cancelled"], default: "Placed" }
}, { timestamps: true });

const User = mongoose.model("User", userSchema);
const Product = mongoose.model("Product", productSchema);
const Order = mongoose.model("Order", orderSchema);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  name: "shopnova.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: MONGODB_URI }),
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000 * 60 * 60 * 24 }
}));
app.use(express.static(path.join(__dirname, "public")));

const safeUser = user => ({ id: user._id, name: user.name, email: user.email, role: user.role });
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ message: "Please log in first." });
  next();
}
async function currentUser(req) {
  if (!req.session.userId) return null;
  return User.findById(req.session.userId).select("-passwordHash");
}
async function requireAdmin(req, res, next) {
  try {
    const user = await currentUser(req);
    if (!user || user.role !== "admin") return res.status(403).json({ message: "Admin access required." });
    req.user = user;
    next();
  } catch (e) { res.status(500).json({ message: "Could not verify permissions." }); }
}

app.get("/api/health", (req, res) => res.json({ status: "ok", app: "ShopNova API" }));

app.post("/api/auth/register", async (req, res) => {
  try {
    const name = String(req.body.name || "").trim();
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (name.length < 2 || !email.includes("@") || password.length < 8)
      return res.status(400).json({ message: "Enter a name, valid email, and password with at least 8 characters." });
    if (await User.findOne({ email })) return res.status(409).json({ message: "An account with this email already exists." });
    const user = await User.create({ name, email, passwordHash: await bcrypt.hash(password, 12), role: "user" });
    req.session.userId = String(user._id);
    res.status(201).json({ user: safeUser(user), message: "Account created successfully." });
  } catch (e) { res.status(500).json({ message: "Registration failed." }); }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.passwordHash)))
      return res.status(401).json({ message: "Incorrect email or password." });
    req.session.userId = String(user._id);
    res.json({ user: safeUser(user), message: "Welcome back!" });
  } catch (e) { res.status(500).json({ message: "Login failed." }); }
});

app.post("/api/auth/logout", (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ message: "Could not log out." });
    res.clearCookie("shopnova.sid");
    res.json({ message: "Logged out." });
  });
});

app.get("/api/auth/me", async (req, res) => {
  try { const user = await currentUser(req); res.json({ user: user ? safeUser(user) : null }); }
  catch (e) { res.status(500).json({ message: "Could not load session." }); }
});

app.get("/api/products", async (req, res) => {
  try {
    const filter = {};
    if (req.query.category && req.query.category !== "All") filter.category = req.query.category;
    if (req.query.search) filter.$or = [
      { name: { $regex: String(req.query.search), $options: "i" } },
      { description: { $regex: String(req.query.search), $options: "i" } }
    ];
    const products = await Product.find(filter).sort({ featured: -1, createdAt: -1 });
    res.json({ products });
  } catch (e) { res.status(500).json({ message: "Could not load products." }); }
});

app.get("/api/products/:id", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ message: "Product not found." });
    res.json({ product });
  } catch (e) { res.status(400).json({ message: "Invalid product ID." }); }
});

app.post("/api/products", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { name, description, category, price, image, stock, featured } = req.body;
    if (!name || !Number.isFinite(Number(price)) || Number(price) < 0)
      return res.status(400).json({ message: "Product name and a valid price are required." });
    const product = await Product.create({ name, description, category, price: Number(price), image, stock: Number(stock ?? 10), featured: Boolean(featured) });
    res.status(201).json({ product, message: "Product created." });
  } catch (e) { res.status(400).json({ message: "Could not create product." }); }
});

app.put("/api/products/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    const allowed = ["name", "description", "category", "price", "image", "stock", "featured"];
    const update = {};
    allowed.forEach(key => { if (req.body[key] !== undefined) update[key] = req.body[key]; });
    const product = await Product.findByIdAndUpdate(req.params.id, update, { new: true, runValidators: true });
    if (!product) return res.status(404).json({ message: "Product not found." });
    res.json({ product, message: "Product updated." });
  } catch (e) { res.status(400).json({ message: "Could not update product." }); }
});

app.delete("/api/products/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    const product = await Product.findByIdAndDelete(req.params.id);
    if (!product) return res.status(404).json({ message: "Product not found." });
    res.json({ message: "Product deleted." });
  } catch (e) { res.status(400).json({ message: "Could not delete product." }); }
});

app.post("/api/orders", requireAuth, async (req, res) => {
  try {
    const { items, shipping } = req.body;
    if (!Array.isArray(items) || !items.length) return res.status(400).json({ message: "Your cart is empty." });
    const requiredFields = ["fullName", "address", "city", "postalCode", "phone"];
    if (!shipping || requiredFields.some(k => !String(shipping[k] || "").trim()))
      return res.status(400).json({ message: "Please complete all shipping fields." });

    // Prices and stock are always taken from the database, never trusted from the browser.
    const normalized = [];
    for (const item of items) {
      const qty = Math.floor(Number(item.quantity));
      if (!item.productId || !Number.isInteger(qty) || qty < 1 || qty > 99)
        return res.status(400).json({ message: "Invalid cart item." });
      const product = await Product.findById(item.productId);
      if (!product) return res.status(400).json({ message: "A product in your cart no longer exists." });
      if (product.stock < qty) return res.status(400).json({ message: `${product.name} does not have enough stock.` });
      normalized.push({ product, quantity: qty });
    }
    const orderItems = normalized.map(({ product, quantity }) => ({
      product: product._id, name: product.name, image: product.image, price: product.price, quantity
    }));
    const total = orderItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    for (const { product, quantity } of normalized) {
      product.stock -= quantity;
      await product.save();
    }
    const order = await Order.create({ user: req.session.userId, items: orderItems, total, shipping });
    res.status(201).json({ order, message: "Order placed successfully." });
  } catch (e) { res.status(500).json({ message: "Could not place order. Please try again." }); }
});

app.get("/api/orders/mine", requireAuth, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.session.userId }).sort({ createdAt: -1 });
    res.json({ orders });
  } catch (e) { res.status(500).json({ message: "Could not load orders." }); }
});

app.get("/api/orders", requireAuth, requireAdmin, async (req, res) => {
  try {
    const orders = await Order.find().populate("user", "name email").sort({ createdAt: -1 });
    res.json({ orders });
  } catch (e) { res.status(500).json({ message: "Could not load orders." }); }
});

app.patch("/api/orders/:id/status", requireAuth, requireAdmin, async (req, res) => {
  const allowed = ["Placed", "Processing", "Shipped", "Delivered", "Cancelled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ message: "Invalid order status." });
  try {
    const order = await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
    if (!order) return res.status(404).json({ message: "Order not found." });
    res.json({ order, message: "Order status updated." });
  } catch (e) { res.status(400).json({ message: "Could not update order." }); }
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`ShopNova running at http://localhost:${PORT}`));
