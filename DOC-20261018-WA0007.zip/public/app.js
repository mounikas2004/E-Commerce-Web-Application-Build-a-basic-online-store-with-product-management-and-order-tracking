const $ = id => document.getElementById(id);
const money = n => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
let products = [], user = null, activeCategory = "All", authMode = "login", editingProductId = null;
let cart = JSON.parse(localStorage.getItem("shopnova-cart") || "[]");
let toastTimer;

async function api(url, options = {}) {
  const res = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}
function toast(message) {
  $("toast").textContent = message;
  $("toast").classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("toast").classList.remove("show"), 2800);
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function saveCart() {
  localStorage.setItem("shopnova-cart", JSON.stringify(cart));
  updateCartCount();
}
function updateCartCount() { $("cart-count").textContent = cart.reduce((sum, i) => sum + i.quantity, 0); }
function imageFallback(img) {
  img.onerror = null;
  img.src = "https://placehold.co/600x600/f0efe8/344d3d?text=ShopNova";
}
function showPage(page) {
  ["cart-page","orders-page","auth-page","admin-page"].forEach(id => $(id).classList.add("hidden"));
  $("hero").classList.toggle("hidden", page !== "shop");
  $("products").classList.toggle("hidden", page !== "shop");
  if (page === "cart") { $("cart-page").classList.remove("hidden"); renderCart(); }
  if (page === "orders") { $("orders-page").classList.remove("hidden"); loadOrders(); }
  if (page === "auth") $("auth-page").classList.remove("hidden");
  if (page === "admin") { $("admin-page").classList.remove("hidden"); loadAdmin(); }
  window.scrollTo({ top: 0, behavior: "smooth" });
}
async function init() {
  try { const data = await api("/api/auth/me"); user = data.user; }
  catch { user = null; }
  updateAccountButton();
  await loadProducts();
  updateCartCount();
}
function updateAccountButton() {
  const btn = $("account-btn");
  if (!user) { btn.textContent = "Sign in"; btn.onclick = showAuth; return; }
  btn.textContent = user.role === "admin" ? "Admin ↗" : user.name.split(" ")[0];
  btn.onclick = () => user.role === "admin" ? showPage("admin") : showPage("orders");
  // Add a logout action to the account control for signed-in users.
  btn.title = "Click to open your account area";
}
async function loadProducts() {
  const search = $("search").value.trim();
  try {
    const query = new URLSearchParams();
    if (search) query.set("search", search);
    if (activeCategory !== "All") query.set("category", activeCategory);
    const data = await api("/api/products?" + query.toString());
    products = data.products;
    renderCategories();
    renderProducts();
  } catch (e) { $("product-grid").innerHTML = `<div class="empty-state">Could not load products. Check that the server and database are running.</div>`; }
}
function renderCategories() {
  const all = ["All", ...new Set(products.map(p => p.category).filter(Boolean))];
  // Keep categories visible even when search narrows the current result set.
  const cats = ["All", "Electronics", "Accessories", "Fashion", "Home", ...all.filter(c => !["All","Electronics","Accessories","Fashion","Home"].includes(c))];
  $("categories").innerHTML = [...new Set(cats)].map(c => `<button class="category-chip ${c === activeCategory ? "active" : ""}" onclick="setCategory('${escapeHTML(c)}')">${escapeHTML(c)}</button>`).join("");
}
function setCategory(category) { activeCategory = category; loadProducts(); }
function renderProducts() {
  if (!products.length) { $("product-grid").innerHTML = `<div class="empty-state">No products found. Try another search or category.</div>`; return; }
  $("product-grid").innerHTML = products.map(p => `
    <article class="product-card">
      <div class="product-photo">
        <img src="${escapeHTML(p.image || "")}" alt="${escapeHTML(p.name)}" onerror="imageFallback(this)">
        ${p.featured ? '<span class="product-tag">EDITOR’S PICK</span>' : ""}
        <button class="quick-add" title="Add to bag" onclick="addToCart('${p._id}')">+</button>
      </div>
      <div class="product-info">
        <div class="product-category">${escapeHTML(p.category || "General")}</div>
        <div class="product-name-row"><h3>${escapeHTML(p.name)}</h3><span class="price">${money(p.price)}</span></div>
        <p class="product-desc">${escapeHTML(p.description || "")}</p>
        <p class="product-desc" style="margin-top:6px">${p.stock > 0 ? `${p.stock} in stock` : "Out of stock"}</p>
      </div>
    </article>`).join("");
}
function addToCart(id) {
  const product = products.find(p => p._id === id);
  if (!product) return toast("Product not found. Refresh and try again.");
  if (product.stock < 1) return toast("This product is currently out of stock.");
  const found = cart.find(i => i.productId === id);
  if (found) {
    if (found.quantity >= product.stock) return toast("You have reached the available stock.");
    found.quantity++;
  } else cart.push({ productId: id, quantity: 1 });
  saveCart();
  toast(`${product.name} added to your bag.`);
}
function changeQty(id, amount) {
  const item = cart.find(i => i.productId === id);
  if (!item) return;
  const product = products.find(p => p._id === id);
  const max = product ? product.stock : 99;
  item.quantity += amount;
  if (item.quantity <= 0) cart = cart.filter(i => i.productId !== id);
  else if (item.quantity > max) { item.quantity = max; toast("Available stock limit reached."); }
  saveCart(); renderCart();
}
function removeItem(id) { cart = cart.filter(i => i.productId !== id); saveCart(); renderCart(); }
function cartDetails() {
  return cart.map(item => {
    const product = products.find(p => p._id === item.productId);
    return product ? { ...item, product } : null;
  }).filter(Boolean);
}
function renderCart() {
  const items = cartDetails();
  if (!items.length) {
    $("cart-content").innerHTML = `<div class="empty-state">Your bag is waiting for something lovely.<br><br><button class="primary-btn" onclick="showPage('shop')">Explore products <span>→</span></button></div>`;
    return;
  }
  const total = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  $("cart-content").innerHTML = `<div class="cart-layout"><div>${items.map(i => `
    <div class="cart-item"><img src="${escapeHTML(i.product.image)}" alt="${escapeHTML(i.product.name)}" onerror="imageFallback(this)">
      <div><h3>${escapeHTML(i.product.name)}</h3><small>${money(i.product.price)} each</small>
        <div class="qty-row"><button onclick="changeQty('${i.productId}',-1)">−</button><span>${i.quantity}</span><button onclick="changeQty('${i.productId}',1)">+</button><button class="remove-btn" onclick="removeItem('${i.productId}')">Remove</button></div>
      </div><b>${money(i.product.price * i.quantity)}</b>
    </div>`).join("")}</div>
    <aside class="summary-card"><h3>Order summary</h3><div class="summary-line"><span>Subtotal</span><span>${money(total)}</span></div><div class="summary-line"><span>Delivery</span><span>${total >= 2999 ? "Free" : "Calculated at checkout"}</span></div><div class="summary-line total"><span>Total</span><span>${money(total)}</span></div><button class="primary-btn full-btn" onclick="beginCheckout()">Continue to checkout <span>→</span></button><p style="font-size:10px;color:var(--muted);line-height:1.6;margin:13px 0 0">Demo checkout only. No real payment is processed.</p></aside></div>`;
}
function showAuth() {
  authMode = "login"; updateAuthMode(); showPage("auth");
}
function toggleAuthMode() { authMode = authMode === "login" ? "register" : "login"; updateAuthMode(); }
function updateAuthMode() {
  const register = authMode === "register";
  $("name-label").classList.toggle("hidden", !register);
  $("auth-name").required = register;
  $("auth-title").innerHTML = register ? "Make it <em>yours.</em>" : "Good to see <em>you.</em>";
  $("auth-subtitle").textContent = register ? "Create an account to keep track of your orders." : "Sign in to see your orders and check out.";
  $("auth-submit").innerHTML = register ? "Create account <span>→</span>" : "Sign in <span>→</span>";
  $("switch-copy").textContent = register ? "Already have an account?" : "New here?";
  $("switch-btn").textContent = register ? "Sign in" : "Create an account";
  $("auth-password").autocomplete = register ? "new-password" : "current-password";
}
async function submitAuth(event) {
  event.preventDefault();
  const body = { email: $("auth-email").value, password: $("auth-password").value };
  if (authMode === "register") body.name = $("auth-name").value;
  try {
    const data = await api(`/api/auth/${authMode}`, { method: "POST", body: JSON.stringify(body) });
    user = data.user; updateAccountButton(); toast(data.message);
    showPage("shop");
  } catch (e) { toast(e.message); }
}
async function logout() {
  try { await api("/api/auth/logout", { method: "POST" }); user = null; updateAccountButton(); toast("You have signed out."); showPage("shop"); }
  catch (e) { toast(e.message); }
}
function beginCheckout() {
  if (!user) { toast("Please sign in before checkout."); showAuth(); return; }
  const items = cartDetails();
  if (!items.length) return toast("Your cart is empty.");
  const total = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);
  $("checkout-total").textContent = `Order total: ${money(total)}`;
  $("checkout-modal").classList.remove("hidden");
}
function closeCheckout() { $("checkout-modal").classList.add("hidden"); }
async function placeOrder(event) {
  event.preventDefault();
  const form = new FormData($("checkout-form"));
  const shipping = Object.fromEntries(form.entries());
  const items = cart.map(i => ({ productId: i.productId, quantity: i.quantity }));
  try {
    const data = await api("/api/orders", { method: "POST", body: JSON.stringify({ items, shipping }) });
    cart = []; saveCart(); closeCheckout(); $("checkout-form").reset();
    toast(`Order placed! Reference: ${data.order._id.slice(-8).toUpperCase()}`);
    showPage("orders");
  } catch (e) { toast(e.message); }
}
async function loadOrders() {
  if (!user) {
    $("orders-content").innerHTML = `<div class="empty-state">Sign in to see your order history.<br><br><button class="primary-btn" onclick="showAuth()">Sign in <span>→</span></button></div>`;
    return;
  }
  try {
    const data = await api("/api/orders/mine");
    if (!data.orders.length) { $("orders-content").innerHTML = `<div class="empty-state">No orders yet. Your next favourite is waiting.<br><br><button class="primary-btn" onclick="showPage('shop')">Start shopping <span>→</span></button></div>`; return; }
    $("orders-content").innerHTML = data.orders.map(order => `<article class="order-card">
      <div class="order-top"><div><b>Order #${order._id.slice(-8).toUpperCase()}</b><br><small>${new Date(order.createdAt).toLocaleString()}</small></div><span class="status-pill">${escapeHTML(order.status)}</span><b>${money(order.total)}</b></div>
      <div class="order-items">${order.items.map(i => `${escapeHTML(i.name)} × ${i.quantity}`).join(" · ")}</div>
      <small style="color:var(--muted)">Delivering to: ${escapeHTML(order.shipping.city)} · ${escapeHTML(order.shipping.postalCode)}</small>
      <div class="tracking"><div class="tracking-track"><span class="${["Placed","Processing","Shipped","Delivered"].includes(order.status) ? "done" : ""}"></span><span class="${["Processing","Shipped","Delivered"].includes(order.status) ? "done" : ""}"></span><span class="${["Shipped","Delivered"].includes(order.status) ? "done" : ""}"></span><span class="${order.status === "Delivered" ? "done" : ""}"></span></div><small>Placed → Processing → Shipped → Delivered</small></div>
    </article>`).join("");
  } catch (e) { $("orders-content").innerHTML = `<div class="empty-state">${escapeHTML(e.message)}</div>`; }
}
async function loadAdmin() {
  if (!user || user.role !== "admin") { $("admin-page").innerHTML = `<div class="empty-state">Admin access is required. Please sign in with an admin account.</div>`; return; }
  try {
    const [productData, orderData] = await Promise.all([api("/api/products"), api("/api/orders")]);
    $("admin-product-list").innerHTML = productData.products.map(p => `<div class="admin-product-row"><div><b>${escapeHTML(p.name)}</b><br><small>${money(p.price)} · Stock ${p.stock}</small></div><div><button class="text-btn" onclick="editProduct('${p._id}')">Edit</button><button class="text-btn" onclick="deleteProduct('${p._id}')">Delete</button></div></div>`).join("") || "No products yet.";
    $("admin-orders-list").innerHTML = orderData.orders.map(o => `<div class="order-card"><div class="order-top"><b>#${o._id.slice(-8).toUpperCase()}</b><b>${money(o.total)}</b></div><small>${escapeHTML(o.user?.name || "Customer")} · ${escapeHTML(o.user?.email || "")}</small><br><select onchange="updateOrderStatus('${o._id}',this.value)">${["Placed","Processing","Shipped","Delivered","Cancelled"].map(s => `<option ${s===o.status?"selected":""}>${s}</option>`).join("")}</select></div>`).join("") || `<p style="font-size:12px;color:var(--muted)">No orders yet.</p>`;
  } catch (e) { toast(e.message); }
}
async function saveProduct(event) {
  event.preventDefault();
  const body = { name: $("p-name").value.trim(), price: Number($("p-price").value), category: $("p-category").value.trim(), stock: Number($("p-stock").value), image: $("p-image").value.trim(), description: $("p-description").value.trim(), featured: $("p-featured").checked };
  try {
    await api(editingProductId ? `/api/products/${editingProductId}` : "/api/products", { method: editingProductId ? "PUT" : "POST", body: JSON.stringify(body) });
    toast(editingProductId ? "Product updated." : "Product added.");
    resetProductForm(); await loadAdmin(); await loadProducts();
  } catch (e) { toast(e.message); }
}
function editProduct(id) {
  const p = products.find(item => item._id === id);
  if (!p) return toast("Refresh the page and try again.");
  editingProductId = id;
  $("product-form-title").textContent = "Edit product";
  $("p-name").value = p.name; $("p-price").value = p.price; $("p-category").value = p.category;
  $("p-stock").value = p.stock; $("p-image").value = p.image; $("p-description").value = p.description;
  $("p-featured").checked = p.featured; $("cancel-edit").classList.remove("hidden");
  $("product-form").scrollIntoView({ behavior: "smooth", block: "center" });
}
function resetProductForm() {
  editingProductId = null; $("product-form").reset(); $("p-stock").value = 10;
  $("product-form-title").textContent = "Add a product"; $("cancel-edit").classList.add("hidden");
}
async function deleteProduct(id) {
  if (!confirm("Delete this product? This cannot be undone.")) return;
  try { await api(`/api/products/${id}`, { method: "DELETE" }); cart = cart.filter(i => i.productId !== id); saveCart(); toast("Product deleted."); await loadAdmin(); await loadProducts(); }
  catch (e) { toast(e.message); }
}
async function updateOrderStatus(id, status) {
  try { await api(`/api/orders/${id}/status`, { method: "PATCH", body: JSON.stringify({ status }) }); toast("Order status updated."); }
  catch (e) { toast(e.message); loadAdmin(); }
}
// Make the account control a small account menu after login.
$("account-btn").addEventListener("contextmenu", e => { e.preventDefault(); if (user && confirm("Sign out of ShopNova?")) logout(); });
init();
