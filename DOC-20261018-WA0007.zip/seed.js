require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema({
  name: String, email: { type: String, unique: true }, passwordHash: String, role: String
}, { timestamps: true });
const productSchema = new mongoose.Schema({
  name: String, description: String, category: String, price: Number, image: String, stock: Number, featured: Boolean
}, { timestamps: true });
const User = mongoose.model("User", userSchema);
const Product = mongoose.model("Product", productSchema);

const products = [
  { name: "Wireless Headphones", category: "Electronics", price: 2499, stock: 18, featured: true, image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85", description: "Comfortable over-ear headphones with rich, clear sound." },
  { name: "Everyday Backpack", category: "Accessories", price: 1599, stock: 24, featured: true, image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=85", description: "A lightweight backpack for college, work and travel." },
  { name: "Minimal Watch", category: "Accessories", price: 3299, stock: 12, featured: true, image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=900&q=85", description: "A clean, timeless watch design for everyday use." },
  { name: "Running Sneakers", category: "Fashion", price: 2899, stock: 15, featured: false, image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85", description: "Everyday sneakers built for comfort and movement." },
  { name: "Ceramic Coffee Mug", category: "Home", price: 499, stock: 35, featured: false, image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&w=900&q=85", description: "A simple ceramic mug for your favourite hot drink." },
  { name: "Desk Lamp", category: "Home", price: 1199, stock: 20, featured: false, image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=85", description: "A warm, focused light for your reading or study desk." },
  { name: "Smart Speaker", category: "Electronics", price: 3999, stock: 9, featured: true, image: "https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=900&q=85", description: "Compact speaker for music and everyday listening." },
  { name: "Sunglasses", category: "Fashion", price: 899, stock: 30, featured: false, image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=900&q=85", description: "Classic frame sunglasses with a versatile look." }
];

async function run() {
  await mongoose.connect(process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/shopnova");
  await Product.deleteMany({});
  await Product.insertMany(products);
  const email = "admin@shopnova.demo";
  let admin = await User.findOne({ email });
  if (!admin) admin = await User.create({
    name: "ShopNova Admin", email, passwordHash: await bcrypt.hash("Admin12345!", 12), role: "admin"
  });
  console.log("Sample products inserted.");
  console.log("Demo admin login: admin@shopnova.demo / Admin12345!");
  console.log("Change the demo admin password before using this beyond local testing.");
  await mongoose.disconnect();
}
run().catch(err => { console.error(err); process.exit(1); });
