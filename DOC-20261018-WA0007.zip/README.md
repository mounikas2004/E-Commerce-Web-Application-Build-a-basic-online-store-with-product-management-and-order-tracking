# ShopNova — Full-Stack E-Commerce Web Application

A portfolio/academic full-stack project matching the requested features: product catalog, cart, checkout, user authentication, Admin/User role access, REST APIs, MongoDB, and order tracking.

## Technology stack
- Frontend: HTML5, CSS3, vanilla JavaScript (responsive design)
- Backend: Node.js + Express.js REST API
- Database: MongoDB + Mongoose
- Authentication: Express sessions + bcrypt password hashing
- Session storage: MongoDB (`connect-mongo`)

## Requirements
Install Node.js (LTS) and MongoDB Community Server, or create a MongoDB Atlas database.

## Run locally
1. Extract the ZIP and open a terminal in the project folder.
2. Install packages:
   ```bash
   npm install
   ```
3. Copy `.env.example` to `.env` and update `MONGODB_URI` and `SESSION_SECRET`.
   - Windows PowerShell: `Copy-Item .env.example .env`
   - macOS/Linux: `cp .env.example .env`
4. Make sure MongoDB is running (or use a MongoDB Atlas URI).
5. Add sample products and a demo admin:
   ```bash
   npm run seed
   ```
6. Start the app:
   ```bash
   npm start
   ```
7. Open **http://localhost:3000** in your browser.

## Demo admin account
- Email: `admin@shopnova.demo`
- Password: `Admin12345!`

This account is created by `npm run seed`. Change the password / remove the demo account before any public deployment. Do not publish your `.env` file.

## How to test
1. Visit the store and search/filter products.
2. Add items to the bag and change quantities.
3. Register a normal user with a password of at least 8 characters.
4. Sign in and checkout with delivery details. This is a demo checkout; no real payment is collected.
5. Visit **My orders** to view order history and tracking status.
6. Sign in as the demo admin and open **Admin** to add/edit/delete products and update order statuses.

## API overview
| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/health` | Public | Health check |
| POST | `/api/auth/register` | Public | Create user |
| POST | `/api/auth/login` | Public | Login |
| POST | `/api/auth/logout` | Session | Logout |
| GET | `/api/auth/me` | Public | Current session |
| GET | `/api/products` | Public | List/search/filter products |
| GET | `/api/products/:id` | Public | Product details |
| POST | `/api/products` | Admin | Create product |
| PUT | `/api/products/:id` | Admin | Update product |
| DELETE | `/api/products/:id` | Admin | Delete product |
| POST | `/api/orders` | User | Place order |
| GET | `/api/orders/mine` | User | Own order history |
| GET | `/api/orders` | Admin | All orders |
| PATCH | `/api/orders/:id/status` | Admin | Update tracking status |

## Database collections
- `users`: name, email, password hash, role
- `products`: name, description, category, price, image, stock
- `orders`: customer, items, server-verified prices, total, shipping details, status

## Important notes
- Checkout is simulated. No payment gateway or card details are collected.
- The backend calculates order totals using database prices; it does not trust prices from the browser.
- For a real production deployment, add CSRF protection, rate limiting, email verification/password reset, stronger order stock transactions, image upload validation, security headers, logging, and a real payment provider. Use HTTPS and a strong secret.
- This starter project is designed to run locally and demonstrate the full-stack features; it is not a production-certified store.
